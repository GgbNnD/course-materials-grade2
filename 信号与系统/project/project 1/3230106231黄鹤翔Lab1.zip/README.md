# TakeAway

Signal and System Project 1

# Content

```
project 1
├─ asset
├─ HexiangHuang.wav
├─ project1.pdf
├─ README.md
└─ src

\asset 中存放project完成过程中产生的图片与音频
\src 中存放project的matlab源代码
HexiangHuang.wav 为project最后生成的音频
project1 为lab的报告文档

```