clc;
close all;
clear;

[y, Fs] = audioread("F:\School\大二下\信号与系统\project\project 1\asset\rain.mp3");